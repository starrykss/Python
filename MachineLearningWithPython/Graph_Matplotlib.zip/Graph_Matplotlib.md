```python
# default 설정
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
np.random.seed(1)
x = np.arange(10)     # 0~9 사이 랜덤 수
y = np.random.randn(10) # 0~1 사이 랜덤 수
print(x)
print(y)
```

    [0 1 2 3 4 5 6 7 8 9]
    [ 1.62434536 -0.61175641 -0.52817175 -1.07296862  0.86540763 -2.3015387
      1.74481176 -0.7612069   0.3190391  -0.24937038]
    


```python
# 그래프 표시
plt.plot(x, y)  # 꺾은선 그래프를 등록
plt.show()
```


![png](output_2_0.png)



```python
## EX1) f(x) = 2x + 3
```


```python
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
def f(x):
    return 2 * x + 3
```


```python
x = np.arange(-5, 5, 1)
y = f(x)
print(x, y)
```

    [-5 -4 -3 -2 -1  0  1  2  3  4] [-7 -5 -3 -1  1  3  5  7  9 11]
    


```python
plt.plot(x, y)
plt.grid(True)   # Grid 추가
plt.show()
```


![png](output_7_0.png)



```python
## EX2) f(x) = (x-2)x(x+2)
```


```python
def f(x):
    return (x - 2) * x * (x + 2)
```


```python
print(f(1))
print(f(np.array([1, 2, 3])))
```

    -3
    [-3  0 15]
    


```python
x = np.arange(-3, 3.5, 0.5)   # 0.5 간격으로 -3~3까지의 숫자 생성
print(x)
```

    [-3.  -2.5 -2.  -1.5 -1.  -0.5  0.   0.5  1.   1.5  2.   2.5  3. ]
    


```python
x = np.linspace(-3, 3, 10)   # -3~3까지의 숫자 생성. 마지막 인자 값이 클수록 곡선이 완만해짐.
print(np.round(x, 2))        # 소수점 둘째자리까지 출력
y = f(x)
```

    [-3.   -2.33 -1.67 -1.   -0.33  0.33  1.    1.67  2.33  3.  ]
    


```python
plt.plot(x, y)
plt.show()
```


![png](output_13_0.png)



```python
## EX3) f(x) = ax^3 + bx^2 + cx + d
```


```python
# 싱글 그래프
```


```python
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
def f(a, b, c, d, x):
    return (a * x ** 3) + (b * x ** 2) + (c * x) + d
```


```python
x = np.linspace(-3, 3, 100)

a = 1
b = 2
c = 3
d = 4

y = f(a, b, c, d, x)
```


```python
plt.plot(x, y, color='orange')   # 곡선 색깔 : Orange
plt.grid(True)                   # Grid 생성
plt.show()
```


![png](output_19_0.png)



```python
# 멀티 그래프
```


```python
# 임의의 a, b, c, d 값 설정
l = [1, 2, 3, 4]
m = [4, 3, 5, 1]
n = [7, 6, 2, 3]
k = [3, 8, 9, 2]

plt.subplot(2, 2, 1)
plt.plot(x, f(l[0], l[1], l[2], l[3], x), color = 'red')

plt.subplot(2, 2, 2)
plt.plot(x, f(m[0], m[1], m[2], m[3], x), color = 'green')

plt.subplot(2, 2, 3)
plt.plot(x, f(n[0], n[1], n[2], n[3], x), color = 'blue')

plt.subplot(2, 2, 4)
plt.plot(x, f(k[0], k[1], k[2], k[3], x), color = 'orange')
```




    [<matplotlib.lines.Line2D at 0x285e5830b08>]




![png](output_21_1.png)



```python
## 이변수 함수 3차원 그래프 : f(x0, x1) = (2x0^2 + x1^2) * exp(-(2x0^2 + x1^2))
```


```python
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
%matplotlib inline
```


```python
def f(x0, x1):
    r = 2 * x0 ** 2 + x1 ** 2
    return r * np.exp(-r)
```


```python
# 임의의 값 입력
xn = 20
x0 = np.linspace(-2, 2, xn)
x1 = np.linspace(-2, 2, xn)
y = np.zeros((len(x0), len(x1)))
for i0 in range(xn):
    for i1 in range(xn):
        y[i1, i0] = f(x0[i0], x1[i1])
```


```python
xx0, xx1 = np.meshgrid(x0, x1)
ax = plt.subplot(1, 1, 1, projection='3d')
ax.plot_surface(xx0, xx1, y, color = 'blue', rstride = 1, cstride = 1, alpha = 0.3, edgecolor = 'black')
```




    <mpl_toolkits.mplot3d.art3d.Poly3DCollection at 0x285e5a1f488>




![png](output_26_1.png)



```python

```
